# Precifica Artesanato — MVP 0.1

## O que funciona
- Calculadora de custo por lote e por peça.
- Materiais editáveis com custo unitário e consumo no lote.
- Mão de obra por hora, energia por kWh, outros custos e reserva de perdas.
- Preço recomendado para a margem selecionada e tabelas de 30%, 40% e 50%.
- Registro manual de ofertas com preço unitário incluindo frete e média simples.
- Histórico local e exportação JSON.
- Interface responsiva para Android e computador.

## Limitação importante
A pesquisa automática do Mercado Livre NÃO está ligada nesta versão. Ela requer uma aplicação registrada no portal de desenvolvedores, confirmação dos recursos de busca permitidos para o caso de uso e um serviço de backend para manter segredos fora do aparelho. Não use scraping ou credenciais privadas no cliente.

## Como testar
Abra `index.html` em um navegador moderno. Para testar a instalação PWA, publique a pasta em uma hospedagem HTTPS (por exemplo, GitHub Pages ou Netlify) e abra a URL no Chrome Android. Use o menu do navegador > **Adicionar à tela inicial** ou **Instalar app** quando disponível.

Observação: abrir o HTML como arquivo local permite testar a calculadora, mas não ativa a instalação PWA nem o service worker.

## Próxima fase: Mercado Livre
1. Registrar uma aplicação no portal oficial: https://developers.mercadolivre.com.br/
2. Revisar os termos, limites e endpoints de busca vigentes.
3. Criar backend (por exemplo, Supabase Edge Functions) para consultar a API e proteger credenciais.
4. Programar atualização diária e ao abrir o app, respeitando limites.
5. Salvar anúncio, título, preço, frete quando disponível, quantidade/pacote, URL e data da consulta.
6. Deduplicar e normalizar os anúncios antes de calcular média/mediana.

## Fórmula usada
Custo do lote = (materiais + mão de obra + energia + outros custos) × (1 + perdas %)
Custo unitário = custo do lote / quantidade do lote
Preço para margem M = custo unitário / (1 - M)

A fórmula de margem pressupõe que taxas de venda estejam incluídas em outros custos ou que não existam. Se houver taxas percentuais sobre a venda, elas devem entrar numa fórmula ampliada.
